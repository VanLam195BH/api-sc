<?php
file_put_contents("log.txt", "");
echo "OK";
?>
